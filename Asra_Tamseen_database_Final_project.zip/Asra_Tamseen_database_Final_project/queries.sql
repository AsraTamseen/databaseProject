-- 1 Show all the memberships and how much was spent for each one of them.
SELECT name, price * counts AS 'total spentmembership_type' 
FROM membership_type JOIN 
	(SELECT membership_id, COUNT(*) AS 'counts' 
		FROM users_have_membership 
        GROUP BY membership_id
	) t 
USING (membership_id); 
-- ------------- 1

-- 2 The top sold and the least sold memberships over a week.
SELECT name AS membership, counts
FROM
(
	SELECT membership_id, COUNT(*) AS 'counts' 
    FROM users_have_membership 
    WHERE start_date >= (NOW() - INTERVAL 1 WEEK)
    GROUP BY membership_id    
) t 
JOIN membership_type USING (membership_id)
ORDER BY counts DESC;
-- ------------------------- 2

-- 3 For each genre, display an artist who has maximum songs for that genre.
WITH song_counts AS 
(
	SELECT artist_id, genre_id, COUNT(*) AS song_count  FROM song JOIN artist_has_song using (song_id) group by genre_id, artist_id
),
final_ids AS
(
	SELECT song_count, artist_id, genre_id FROM song_counts sc WHERE song_count =
	(
		SELECT MAX(song_count) FROM song_counts WHERE genre_id = sc.genre_id
	)
)
SELECT g.name AS 'genre', a.Name AS 'artist', song_count 
FROM final_ids JOIN artist a USING (artist_id) JOIN genre g USING (genre_id) 
ORDER BY  genre, song_count DESC;
-- --------------------- 3

-- 4 List how many customers the system has by location (Country, Province, and City), and then sort them.

SELECT country, province, city, COUNT(*) AS 'number_of_users'
FROM users 
GROUP BY country, province, city
ORDER BY country, province, city;

-- -------------------- 4

-- 5 List how many memberships the store has sold for a particular month.

SELECT COUNT(*) AS 'total_sold' FROM users_have_membership WHERE MONTH(start_date) = 4;

-- ---------------- 5

-- 6 List how many songs each artist has.
SELECT Name, COUNT(*) AS song_count 
FROM song JOIN artist_has_song USING (song_id) 
	JOIN artist USING (artist_id)
GROUP BY (artist_id);
-- ------------------6


-- 7 List for each user which song is played the most by them.
SELECT Name, title
FROM users_has_song uhs
JOIN song USING (song_id)
JOIN users USING (user_id)
WHERE number_of_times_played =
(
	SELECT IFNULL(MAX(number_of_times_played), 0)
    FROM users_has_song 
    WHERE uhs.user_id = user_id
);
-- ---------------------- 7

-- Specific Scenario

-- 1 Filter songs according to language	
SELECT title 
FROM song JOIN language USING (language_id)
WHERE language_name = 'Hindi';
-- ----------------------- 1

-- 2  The most popular song according to the language	
WITH summed_song_playcount AS
(
	SELECT SUM(number_of_times_played) AS song_total_played, title
	FROM users_has_song JOIN song USING (song_id)
		JOIN language USING (language_id)
	WHERE language_name = 'English'
	GROUP BY song_id
)
SELECT title
FROM summed_song_playcount WHERE song_total_played = (SELECT MAX(song_total_played) from summed_song_playcount);
-- ------------------------ 2


-- -----------------------------------------------------------------------------------------------------------------------------------------
-- TRIGGERS

-- A trigger which inserts end_date of the membership by calculating the days from the membership type of the user
DROP TRIGGER IF EXISTS membership_dates_trigger_insert;

DELIMITER // 

CREATE TRIGGER membership_dates_trigger_insert
BEFORE INSERT ON users_have_membership
FOR EACH ROW 
BEGIN
	DECLARE end_date_var INT;
    
	SELECT validity INTO end_date_var
    FROM membership_type WHERE membership_id = NEW.membership_id;
    
    SET NEW.end_date = NEW.start_date + INTERVAL end_date_var DAY;
    
    IF NEW.end_date < DATE(NOW()) THEN
		SET NEW.isExpired = TRUE;
    ELSE
		SET NEW.isExpired = FALSE;
	END IF;
END//

DELIMITER ;

-- A trigger which updates an end_date if the start_date is modified.

DROP TRIGGER IF EXISTS membership_dates_trigger_update;
DELIMITER // 

CREATE TRIGGER membership_dates_trigger_update
BEFORE UPDATE ON users_have_membership
FOR EACH ROW 
BEGIN
	DECLARE end_date_var INT;
    
    IF NEW.start_date <> OLD.start_date THEN
    
    	SELECT validity INTO end_date_var
		FROM membership_type WHERE membership_id = NEW.membership_id;
    
		SET NEW.end_date = NEW.start_date + INTERVAL end_date_var DAY;
		
		IF NEW.end_date < DATE(NOW()) THEN
			SET NEW.isExpired = TRUE;
		ELSE
			SET NEW.isExpired = FALSE;
		END IF;
    END IF;
END//

DELIMITER ;
-- ---------------


-- PROCEDURES
DROP PROCEDURE IF EXISTS check_and_update_membership_status;
DELIMITER //
CREATE PROCEDURE check_and_update_membership_status()
BEGIN
	DECLARE end_date_var DATE;
    DECLARE id_var INT;
    DECLARE row_not_found TINYINT DEFAULT FALSE;
    
    DECLARE user_membership_cursor CURSOR FOR 
		SELECT id, end_date FROM users_have_membership;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND 
		SET row_not_found = TRUE;
	
    OPEN user_membership_cursor;
    
    WHILE row_not_found = FALSE DO
		FETCH user_membership_cursor INTO id_var, end_date_var;
        
        IF end_date_var < DATE(NOW()) THEN
			UPDATE users_have_membership SET isExpired = TRUE 
			WHERE id = id_var;
        END IF;
	END WHILE;
    CLOSE user_membership_cursor;
END//
DELIMITER ;
-- ----------------------------------------------------------------------------------------------------------

-- ----------------------------------------------------------------------------------------------------------
-- EVENTS
DROP EVENT IF EXISTS check_expired_event;
DELIMITER //
CREATE EVENT check_expired_event 
ON SCHEDULE 
EVERY 1 DAY 
DO BEGIN
	CALL check_and_update_membership_status();
END //
DELIMITER ;
-- 